<template>
  <div>
    <Default/>
  </div>
</template>
<script>
import Default from './layout/Default.vue';
export default {
  data() {
    return {
      
    }
  },
  components:{
    Default
  }
}
</script>
<style>
  
</style>